<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>path_Today_cls-1</name>
   <tag></tag>
   <elementGuidId>5782ef8f-5960-4dfb-834d-6483e0541ffc</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>button.oxd-icon-button.orangehrm-quick-launch-icon > svg.oxd-icon > g > path.cls-1</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=button[name=&quot;Assign Leave&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>path</value>
      <webElementGuid>d20f58e7-0e72-408c-978f-111d32d3d028</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>cls-1</value>
      <webElementGuid>7efff21a-89c5-4113-a71b-85402a6c7918</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>d</name>
      <type>Main</type>
      <value>M 188.985 218.979 C 159.632 254.855 143.608 300.074 143.716 346.716 C 143.644 365.219 146.195 383.687 151.261 401.46 L 145.871 401.46 C 54.973 401.46 2.158 370.803 0.003 308.395 L 0.003 273.723 C -0.285 245.293 20.985 221.46 48.865 218.979 L 188.985 218.979 Z M 143.716 0.001 C 212.878 0.001 256.063 76.023 221.5 136.862 C 186.937 197.701 100.494 197.701 65.931 136.862 C 58.063 122.993 53.895 107.263 53.895 91.242 C 53.895 40.84 94.099 0.001 143.716 0.001 Z M 323.357 36.497 C 363.058 36.497 395.213 69.161 395.213 109.49 C 395.249 124.052 391.01 138.285 382.998 150.366 C 369.309 147.446 355.333 145.95 341.321 145.986 C 316.782 145.913 292.423 150.366 269.465 159.125 C 231.848 117.92 252.219 50.804 306.147 38.322 C 311.788 37.008 317.572 36.388 323.357 36.497 Z M 343.117 182.482 C 463.441 182.19 538.926 314.307 478.998 420.292 C 419.106 526.278 268.71 526.643 208.315 420.949 C 194.482 396.716 187.189 369.234 187.189 341.241 C 187.189 253.687 256.961 182.701 343.117 182.482 Z M 398.447 291.971 L 323.357 368.614 L 287.429 332.117 C 280.387 324.964 268.351 328.249 265.764 338.03 C 264.542 342.555 265.836 347.409 269.105 350.73 L 314.734 397.081 C 319.8 402.227 327.992 402.227 333.058 397.081 L 416.77 311.679 C 423.812 304.526 420.615 292.3 410.95 289.672 C 406.495 288.431 401.716 289.745 398.447 293.066 L 398.447 291.971 Z</value>
      <webElementGuid>b3647045-26ba-4298-91ba-3e40ba10a18d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;app&quot;)/div[@class=&quot;oxd-layout orangehrm-upgrade-layout&quot;]/div[@class=&quot;oxd-layout-container&quot;]/div[@class=&quot;oxd-layout-context&quot;]/div[@class=&quot;oxd-grid-3 orangehrm-dashboard-grid&quot;]/div[@class=&quot;oxd-grid-item oxd-grid-item--gutters orangehrm-dashboard-widget&quot;]/div[@class=&quot;oxd-sheet oxd-sheet--rounded oxd-sheet--white orangehrm-dashboard-widget&quot;]/div[@class=&quot;orangehrm-dashboard-widget-body&quot;]/div[@class=&quot;oxd-grid-3 orangehrm-quick-launch&quot;]/div[@class=&quot;oxd-grid-item oxd-grid-item--gutters orangehrm-quick-launch-card&quot;]/button[@class=&quot;oxd-icon-button orangehrm-quick-launch-icon&quot;]/svg[@class=&quot;oxd-icon&quot;]/g[1]/path[@class=&quot;cls-1&quot;]</value>
      <webElementGuid>ee47ba3a-8e31-44e3-91b5-bceedb6f0abe</webElementGuid>
   </webElementProperties>
</WebElementEntity>
