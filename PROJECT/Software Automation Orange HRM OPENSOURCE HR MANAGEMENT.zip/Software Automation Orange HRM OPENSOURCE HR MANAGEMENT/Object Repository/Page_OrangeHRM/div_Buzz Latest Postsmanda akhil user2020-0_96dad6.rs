<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Buzz Latest Postsmanda akhil user2020-0_96dad6</name>
   <tag></tag>
   <elementGuidId>fd414320-4486-4357-9cfa-79c641e05f6b</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='app']/div/div[2]/div[2]/div/div[4]/div</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;Buzz Latest Postsmanda akhil user2020-08-10 09:08 AMHi All; Linda has been bless&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>10559ea9-3f86-49c7-93ca-f873255447b7</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>oxd-sheet oxd-sheet--rounded oxd-sheet--white orangehrm-dashboard-widget</value>
      <webElementGuid>42f3b454-4614-4b08-ace6-f07c8c339af6</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Buzz Latest Postsmanda akhil user2020-08-10 09:08 AMHi All;&#xd;
&#xd;
Linda has been blessed with a baby boy!&#xd;
&#xd;
&#xd;
&#xd;
Linda: With love, we welcome your dear new baby to this world. Congratulations!Sania  Shaheen2020-08-10 09:08 AMWorld Championship: What makes the perfect snooker player?&#xd;
&#xd;
Mark Selby: Robertson has one of the best techniques in the game. It is very, very straight and he fully commits to every single shot he plays.&#xd;
&#xd;
John Higgins: Every shot is repetitive. He always keeps the same technique and cues through the ball bang straight.&#xd;
&#xd;
Barry Hawkins: Robertson is textbook with his grip and has a ramrod solid cue action, delivering it in a straight line.&#xd;
&#xd;
Honourable mentions: Shaun Murphy, Ding Junhui, Jack Lisowski.Rebecca  Harmony2020-08-10 09:04 AM Throwback Thursdays!! Russel  Hamilton2020-08-10 09:03 AMLive SIMPLY&#xd;
Dream BIG&#xd;
Be GREATFULL&#xd;
Give LOVE&#xd;
Laugh LOT.......</value>
      <webElementGuid>6784c63c-fe7e-443e-ac51-9c87937d0d65</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;app&quot;)/div[@class=&quot;oxd-layout orangehrm-upgrade-layout&quot;]/div[@class=&quot;oxd-layout-container&quot;]/div[@class=&quot;oxd-layout-context&quot;]/div[@class=&quot;oxd-grid-3 orangehrm-dashboard-grid&quot;]/div[@class=&quot;oxd-grid-item oxd-grid-item--gutters orangehrm-dashboard-widget&quot;]/div[@class=&quot;oxd-sheet oxd-sheet--rounded oxd-sheet--white orangehrm-dashboard-widget&quot;]</value>
      <webElementGuid>e8ee08f9-7fed-49ee-9192-909d74423ab7</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='app']/div/div[2]/div[2]/div/div[4]/div</value>
      <webElementGuid>097cbc2b-3a45-4dd0-a8a2-06af5b5431e8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[4]/div</value>
      <webElementGuid>24f5e4e2-87fa-487b-b9a5-b06545d9f04d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = 'Buzz Latest Postsmanda akhil user2020-08-10 09:08 AMHi All;&#xd;
&#xd;
Linda has been blessed with a baby boy!&#xd;
&#xd;
&#xd;
&#xd;
Linda: With love, we welcome your dear new baby to this world. Congratulations!Sania  Shaheen2020-08-10 09:08 AMWorld Championship: What makes the perfect snooker player?&#xd;
&#xd;
Mark Selby: Robertson has one of the best techniques in the game. It is very, very straight and he fully commits to every single shot he plays.&#xd;
&#xd;
John Higgins: Every shot is repetitive. He always keeps the same technique and cues through the ball bang straight.&#xd;
&#xd;
Barry Hawkins: Robertson is textbook with his grip and has a ramrod solid cue action, delivering it in a straight line.&#xd;
&#xd;
Honourable mentions: Shaun Murphy, Ding Junhui, Jack Lisowski.Rebecca  Harmony2020-08-10 09:04 AM Throwback Thursdays!! Russel  Hamilton2020-08-10 09:03 AMLive SIMPLY&#xd;
Dream BIG&#xd;
Be GREATFULL&#xd;
Give LOVE&#xd;
Laugh LOT.......' or . = 'Buzz Latest Postsmanda akhil user2020-08-10 09:08 AMHi All;&#xd;
&#xd;
Linda has been blessed with a baby boy!&#xd;
&#xd;
&#xd;
&#xd;
Linda: With love, we welcome your dear new baby to this world. Congratulations!Sania  Shaheen2020-08-10 09:08 AMWorld Championship: What makes the perfect snooker player?&#xd;
&#xd;
Mark Selby: Robertson has one of the best techniques in the game. It is very, very straight and he fully commits to every single shot he plays.&#xd;
&#xd;
John Higgins: Every shot is repetitive. He always keeps the same technique and cues through the ball bang straight.&#xd;
&#xd;
Barry Hawkins: Robertson is textbook with his grip and has a ramrod solid cue action, delivering it in a straight line.&#xd;
&#xd;
Honourable mentions: Shaun Murphy, Ding Junhui, Jack Lisowski.Rebecca  Harmony2020-08-10 09:04 AM Throwback Thursdays!! Russel  Hamilton2020-08-10 09:03 AMLive SIMPLY&#xd;
Dream BIG&#xd;
Be GREATFULL&#xd;
Give LOVE&#xd;
Laugh LOT.......')]</value>
      <webElementGuid>aa4f2df9-1dfb-4724-8749-c1bda4e59062</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
